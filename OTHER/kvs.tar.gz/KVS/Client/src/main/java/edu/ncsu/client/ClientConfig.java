package edu.ncsu.client;

/**
 * Created by amit on 1/4/17.
 */
public class ClientConfig {
  public static String bootStrapIP = "172.17.0.2";

  public static int RMI_REGISTRY_PORT = 1099;
}
