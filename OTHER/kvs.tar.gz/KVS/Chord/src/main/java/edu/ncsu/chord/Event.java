package edu.ncsu.chord;

/**
 * Created by amit on 13/4/17.
 */
public enum Event {
  SUCCESSOR_FAILED,
  NEW_SUCCESSOR,
  PREDECESSOR_FAILED,
  NEW_PREDECESSOR
}
