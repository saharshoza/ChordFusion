#!/bin/bash
sudo docker unpause $(sudo docker ps -a -q)
