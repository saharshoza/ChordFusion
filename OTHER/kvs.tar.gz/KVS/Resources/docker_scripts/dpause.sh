#!/bin/bash
sudo docker pause $(sudo docker ps -a -q)
