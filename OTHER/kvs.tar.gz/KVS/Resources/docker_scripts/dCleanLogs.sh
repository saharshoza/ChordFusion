sudo truncate -s 0 ~/log_server/logs/keystore.log
sudo truncate -s 0 ~/log_server/logs/chord.log
sudo truncate -s 0 ~/log_server/logs/analysis.log