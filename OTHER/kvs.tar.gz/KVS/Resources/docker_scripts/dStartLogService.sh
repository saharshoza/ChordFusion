sudo nohup java -classpath ~/log_server/log4j.jar org.apache.log4j.net.SimpleSocketServer 4712 ~/log_server/log4j.Chord.properties </dev/null >/dev/null 2>&1 &

sudo nohup java -classpath ~/log_server/log4j.jar org.apache.log4j.net.SimpleSocketServer 4713 ~/log_server/log4j.KeyStore.properties </dev/null >/dev/null 2>&1 &

sudo nohup java -classpath ~/log_server/log4j.jar org.apache.log4j.net.SimpleSocketServer 4714 ~/log_server/log4j.Analysis.properties </dev/null >/dev/null 2>&1 &