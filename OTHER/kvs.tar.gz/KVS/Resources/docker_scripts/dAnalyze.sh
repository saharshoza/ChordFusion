#!/bin/bash

python ~/chronstore/Resources/docker_scripts/logAnalyzer.py $1 $2
