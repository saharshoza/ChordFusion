




public class InterfaceException extends Exception{

}
