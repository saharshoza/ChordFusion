
import java.util.PriorityQueue;
/*comment out the exact data structure you need. Any of the implementing classes
can be chosen: http://docs.oracle.com/javase/6/docs/api/java/util/Queue.html
*/


public class GenericQueue<E> extends PriorityQueue<E>{}
//public class GenericQueue<E> extends ArrayDeQue<E>{}
