#include <iostream>
using namespace std;
int main(){
int a=5;
char b=a;
cout << "hello world\n";
cout <<b[0];
}
