
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Vector;

/*comment out the exact data structure you need. Any of the implementing classes
can be chosen: http://docs.oracle.com/javase/6/docs/api/java/util/List.html
*/


public class GenericList<E> extends LinkedList<E>{}

//public class GenericList<E> extends Stack<E>{}
//public class GenericList<E> extends ArrayList<E>{}
//public class GenericList<E> extends Vector<E>{}

